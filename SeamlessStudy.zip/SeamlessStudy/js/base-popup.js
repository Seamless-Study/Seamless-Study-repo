document.addEventListener("DOMContentLoaded", () => {
    display();
    attachEventSaveTabs();
    attachClickListener();
    addEventListenerForPersistChange();
    addEventListenerForSaveName();
})
    
